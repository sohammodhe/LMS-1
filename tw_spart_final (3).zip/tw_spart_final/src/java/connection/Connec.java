/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connec {
    
    public Connection con;  
         
    public Connection getConnection(){
        try{
                    
                    Class.forName("oracle.jdbc.OracleDriver");
                     con=DriverManager.getConnection("jdbc:oracle:thin:@10.212.0.224:1521:XE","DAC15_150840320096","150840320096");
                    
                    
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    return con;
    
}
}
