/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;


import java.util.List;
import Bean.Login;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LoginDao {
    
    public boolean valid(Login lg)
    {
        boolean flag=false;      
        SessionFactory sf=new Configuration().configure().buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Register where uName=? and uPass=? ");
        q.setString(0,lg.getuName());
        q.setString(1, lg.getuPass());
        List<Login> l=q.list();
        if(l.isEmpty())
        {
            return flag;
        }
        else
        {
            flag=true;
        }
        t.commit();
        s.close();
        sf.close();
        return flag;
    
    }
}
