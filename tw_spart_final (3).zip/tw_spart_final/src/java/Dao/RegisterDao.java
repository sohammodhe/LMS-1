/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import java.sql.Connection;
import Bean.Register;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author 150840320096
 */
public class RegisterDao {
    //private Connection con; 
  private SessionFactory sf;
  private Session s;
  private Transaction t;  
  
  
  public void insert(Register r)
    {
   sf= new Configuration().configure().buildSessionFactory();
   s=sf.openSession();
    t=s.beginTransaction();
   s.save(r);
   t.commit();
   s.close();
   sf.close();
           //con.close();
        
    }
    
}
