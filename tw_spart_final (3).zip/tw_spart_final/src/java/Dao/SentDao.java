package Dao;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import Bean.Sentences;

/**
 *
 * @author 150840320096
 */
public class SentDao {
    public ArrayList<String> edit1(Sentences sent)
    {
        String a=sent.getSent();
        BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);


iterator.setText(a);                                  
//int i=0;
int start = iterator.first();
 
      

ArrayList<String> m=new  ArrayList<>();
//m.put(i, a);
for (int end = iterator.next();
        end != BreakIterator.DONE;
        start = end, end = iterator.next()) {
  //  i++;
  

        
      m.add(a.substring(start,end));
// Set set = m;
      // Get an iterator
      Iterator k = m.iterator();
      // Display elements
      while(k.hasNext()) {
          k.next();
//         Map.Entry me = (Map.Entry)k.next();
//         System.out.print(me.getKey() + ": ");
//         System.out.println(me.getValue());
//         
      }
      System.out.println();

        }
       
    
    return m;
}
    
 
    public Map<Integer,String> edit(Sentences sent)
    {    

      String a=sent.getSent();
 
BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);


iterator.setText(a);                                  
int i=0;
int start = iterator.first();
 
      

Map<Integer,String>m=new  HashMap<>();
//m.put(i, a);
for (int end = iterator.next();
        end != BreakIterator.DONE;
        start = end, end = iterator.next()) {
    i++;
  

        
      m.put(i, a.substring(start,end));
 Set set = m.entrySet();
      // Get an iterator
      Iterator k = set.iterator();
      // Display elements
      while(k.hasNext()) {
         Map.Entry me = (Map.Entry)k.next();
         System.out.print(me.getKey() + ": ");
         System.out.println(me.getValue());
         
      }
      System.out.println();

        }
       
    
    return m;
}
 
  
}

