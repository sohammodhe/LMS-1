/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import connection.MysqlConn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 150840320096
 */
public class DbCall {
    public String dbCall(String a) throws SQLException
    {
       String s=null;
    boolean b=false;
    MysqlConn c=new MysqlConn();
    Connection con=c.getConnection();
    PreparedStatement ps=con.prepareStatement("select hin_op from changes where eng_ip=?");
    ps.setString(1, a);
        ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
        
          
                //s=rs.getString(1);
                   // System.out.println("++++++++++++++++++++3545646.854634365+69+++++++++");
                return rs.getString(1);
           
            }
            //rs.getString(3);
        
                   

       
       return null;
    
}
}
