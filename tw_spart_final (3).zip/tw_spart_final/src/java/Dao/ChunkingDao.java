/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import opennlp.tools.cmdline.PerformanceMonitor;
import opennlp.tools.cmdline.postag.POSModelLoader;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSSample;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.WhitespaceTokenizer;
import opennlp.tools.util.ObjectStream;
import opennlp.tools.util.PlainTextByLineStream;
/**
 *
 * @author 150840320102
 */
public class ChunkingDao {
    
    
    public static String chunkData(String input) throws IOException {
	POSModel model = new POSModelLoader()
			.load(new File("C:\\Users\\CDAC\n" +
"\\Downloads\\spartans\n" +
"\\en-pos-maxent.bin "));
	PerformanceMonitor perfMon = new PerformanceMonitor(System.err, "sent");
	POSTaggerME tagger = new POSTaggerME(model);
 
	//String input = "Sudhir Shinde From Sangli.";
       // String input = "Cerezo Osaka noticed his talent and signed him at the age of 17. He was the first player in Japan to sign a professional contract before graduating from high school, except players promoted from youth teams of the J. League clubs.[11] In 2007, he gained a regular position but the club missed promotion to the J. League Division 1. It was in 2009 that he became the top scorer of J. League Division 2 and drew widespread attention.";
	ObjectStream<String> lineStream = new PlainTextByLineStream(
			new StringReader(input));
 
	perfMon.start();
	String line;
        POSSample sample = null;
	String whitespaceTokenizerLine[] = null;
 
	String[] tags = null;
	while ((line = lineStream.read()) != null) {
		whitespaceTokenizerLine = WhitespaceTokenizer.INSTANCE
				.tokenize(line);
		tags = tagger.tag(whitespaceTokenizerLine);
 
		sample = new POSSample(whitespaceTokenizerLine, tags);
		System.out.println(sample);
                
			//perfMon.incrementCounter();
	}
        return sample.toString();
    }
}
