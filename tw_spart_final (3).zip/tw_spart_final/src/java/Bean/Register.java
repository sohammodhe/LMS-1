/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

/**
 *
 * @author 150840320096
 */
public class Register {
    String uName;
    String uPass;
    String uCPass;
    String email;
    
        public Register() {
    }
    

    public Register(String uName, String uPass, String uCPass, String email) {
        this.uName = uName;
        this.uPass = uPass;
        this.uCPass = uCPass;
        this.email = email;
    }

    public Register(String uName) {
        this.uName = uName;
    }



    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuPass() {
        return uPass;
    }

    public void setuPass(String uPass) {
        this.uPass = uPass;
    }

    public String getuCPass() {
        return uCPass;
    }

    public void setuCPass(String uCPass) {
        this.uCPass = uCPass;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return  uName + "" + uPass + "" + uCPass + "" + email ;
    }
    
    
    
}
