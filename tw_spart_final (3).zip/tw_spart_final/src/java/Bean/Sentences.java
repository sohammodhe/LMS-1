package Bean;

public class Sentences {
     
    String sent;


    public Sentences(String sent) {
       
        this.sent = sent;
    }

    


    public String getSent() {
        return sent;
    }

    public void setSent(String sent) {
        this.sent = sent;
    }

    @Override
    public String toString() {
        return  sent ;
    }

    
    
    
    
    
}
